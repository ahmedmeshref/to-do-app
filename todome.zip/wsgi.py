from app import app

if __name__ == '__main__':
    app.run()

"""
Todo:
1- When the user deletes the current selected list, the page refreshes 
2- When you add a new task, you should be able to delete it and change its state 
3- When first list gets created, the system should refer to it
"""
